LANGUAGE: English
Attention!!! Please read the instructions carefully before using this program!
By using this program, you agree to all the terms and conditions listed below!

This is a simple and unique BFC (BATCH FILE CREATOR) 1.0.0 program
With this program, you can create or generate bat viruses!
conditions:
We are not responsible for any of your actions!
If you encounter any problems, the program will not be involved in them!

HOW TO USE THE PROGRAM CORRECTLY?
- Select file names
 - Select the virus creation method.
- Then just select the options by specifying their numbers and the code is automatically registered in the created file
- When you want to finish working with the virus, enter "exit"
 - Done! The virus was successfully created!

A NOTE:
 - The virus file is saved in the current program directory!!!

TO MAKE THE PROGRAM WORK CORRECTLY, YOU NEED:
- To manage the program, enter the action numbers.
 - Disable anti-virus

THE PROGRAM IS IN INITIAL DEVELOPMENT ALL BUGS ARE FIXED WITH EACH NEW VERSION!
STAY TUNED FOR MORE UPDATES!)
HAVE FUN USING IT!!!
BFC (BATCH FILE CREATOR) 1.1.0
BY GENKACODER

***************************************

LANGUAGE: Русский (Russian) 

ВНИМАНИЕ!!! Перед пользаванием данной программой прочтите внимательно инкструкцию!
Пользуясь этой программой вы соглашаетесь со всеми условиями указаными ниже!

Это простая и уникальная программа BFC (BATCH FILE CREATOR) 1.0.0
С помощью этой программы вы сможете создавать или генерировать бат вирусы!

УСЛОВИЯ:
Мы не несем ответственость за какие либо ваши действия!
При возникновении каких либо проблем, программа не будет причастна к ним!

КАК ПРАВИЛЬНО ПОЛЬЗОВАТЬСЯ ПРОГРАММОЙ?
- Выберите названия файла
- Выберите способ создание вируса.
- Дальше просто выбираете опции указывая их номера и код автоматически прописываеться в созданный файл
- Когда вы захотите заверщить работу с вирусом, введите "exit"
- Готово! Вирус успешно создан!

ЗАМЕТКА:
- Файл вируса сохраняеться в текущем каталоге программы!!!

ЧТО БЫ ПРОГРАММА РАБОТАЛА ПРАВИЛЬНО НУЖНО:
- Для управления программой надо вписывать номера действий.
- Отключить анти-вирус

ПРОГРАММА В НАЧАЛЬНОЙ РАЗРАБОТКЕ ВСЕ БАГИ ИСПРАВЛЯЮТЬСЯ С КАЖДОЙ НОВОЙ ВЕРСИЕЙ!
СЛЕДИТЕ ЗА ОБНОВЛЕНИЯМИ!)
УДАЧНОГО ПОЛЬЗОВАНИЯ!!!
BFC (BATCH FILE CREATOR) 1.1.0
BY GENKACODER